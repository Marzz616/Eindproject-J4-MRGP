<?php
declare(strict_types=1);

/**
 * De tijdzone van de voedselbank. Een container draait standaard op UTC; in de
 * winter scheelt dat een uur met de klok in Nederland en in de zomer twee. Daar
 * gaan "vandaag", "deze week" en de eerstvolgende levering op onderuit, dus
 * zetten we PHP én de databaseverbinding op dezelfde zone als de gebruiker.
 */
const APP_TIJDZONE = 'Europe/Amsterdam';
date_default_timezone_set(getenv('APP_TZ') ?: APP_TIJDZONE);

/** Eén centrale databaseverbinding (PDO). */
function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $host = getenv('DB_HOST') ?: 'db';
    $name = getenv('DB_NAME') ?: 'voedselbank';
    $user = getenv('DB_USER') ?: 'vbuser';
    $pass = getenv('DB_PASS') ?: 'vbpass';

    $pdo = new PDO("mysql:host={$host};dbname={$name};charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);

    // MySQL kent de naam "Europe/Amsterdam" alleen als de tijdzonetabellen
    // geladen zijn; die zitten niet in het standaard image. De offset van dit
    // moment (+01:00 of +02:00) werkt altijd en houdt rekening met zomertijd.
    $pdo->exec("SET time_zone = '" . (new DateTimeImmutable('now'))->format('P') . "'");

    return $pdo;
}

/** Stuurt JSON terug en stopt. */
function json_out(mixed $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** Leest de JSON-body van een POST-verzoek. */
function json_in(): array
{
    $data = json_decode(file_get_contents('php://input') ?: '', true);
    return is_array($data) ? $data : [];
}

/** Eén plek voor foutafhandeling: nooit een stacktrace naar de browser. */
function api_boot(): void
{
    set_exception_handler(function (Throwable $e): void {
        error_log('[api] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
        json_out(['fout' => 'Er ging iets mis op de server.'], 500);
    });
}

/** Leest een instelling uit de tabel Instelling. */
function instelling(string $sleutel, string $standaard = ''): string
{
    $q = db()->prepare("SELECT Waarde FROM Instelling WHERE Sleutel = ?");
    $q->execute([$sleutel]);
    $w = $q->fetchColumn();
    return $w === false ? $standaard : (string) $w;
}

/** Verplicht POST; anders 405. */
function alleen_post(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        json_out(['fout' => 'Gebruik POST voor deze actie.'], 405);
    }
}
