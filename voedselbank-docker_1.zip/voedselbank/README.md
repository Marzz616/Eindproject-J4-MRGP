# Voedselbank Maaskantje — back-office

Volledige webapplicatie voor het eindproject: klanten, producten, leveranciers,
voedselpakketten, uitgifte, rapportages en gebruikersbeheer. Gebouwd met
PHP 8 + MySQL 8 (Docker) en een frontend van gewoon HTML, CSS en JavaScript.

---

## 1. Lokaal installeren vanaf nul

Je hebt alleen **Docker Desktop** nodig (en VS Code om de code te bekijken).

```bash
# 1. ga naar de projectmap
cd voedselbank

# 2. bouw en start alles (eerste keer duurt 1-2 minuten)
docker compose up -d --build

# 3. kijk of alle drie de containers draaien
docker compose ps
```

Klaar. Open in je browser:

| Wat | Adres |
|---|---|
| De applicatie | http://localhost:8080 |
| phpMyAdmin (database bekijken) | http://localhost:8081 |
| MySQL van buitenaf (Workbench) | `127.0.0.1` poort `3307`, gebruiker `vbuser`, wachtwoord `vbpass` |

De database wordt bij de **eerste** start automatisch gevuld met `db/01-schema.sql`
en `db/02-seed.sql`.

> **Draaide er al een oudere versie?** Het schema is uitgebreid (voorkeuren per
> gezin en uitzonderingen op een dieetwens). Start dan één keer met een schone
> database: `docker compose down -v` gevolgd door `docker compose up -d --build`.

**Tijdzone.** De containers staan op `Europe/Amsterdam` (zie `TZ` in
`docker-compose.yml` en `src/db.php`). Zonder die instelling draait een
container op UTC en loopt "vandaag" in de applicatie een of twee uur achter op
de klok van de medewerker — precies rond middernacht gaat dat mis bij de
weekcyclus en bij de eerstvolgende leverdatum. Staat de voedselbank ergens
anders, dan pas je `TZ` en `APP_TZ` aan.

### Inloggen

Wachtwoord van alle testaccounts: **`voedselbank`**

| Gebruikersnaam | Rol |
|---|---|
| `p.abraham` | Directie (mag alles) |
| `m.snel` | Administratie |
| `r.veenstra` | Magazijnmedewerker |
| `a.degroot` | Vrijwilliger |
| `k.degraaf` | Vrijwilliger — geblokkeerd, om te laten zien dat blokkeren werkt |

### Opnieuw beginnen met verse testdata

```bash
docker compose down -v      # -v gooit ook de database weg
docker compose up -d --build
```

Alleen de data opnieuw laden (containers laten draaien):

```bash
docker compose exec -T db mysql -uroot -prootpass < db/01-schema.sql
docker compose exec -T db mysql -uroot -prootpass < db/02-seed.sql
```

### Stoppen

```bash
docker compose down         # zonder -v blijft de database bewaard
```

### Veelvoorkomende problemen

| Probleem | Oplossing |
|---|---|
| `port is already allocated` | Iets anders gebruikt poort 8080/8081/3307. Pas de linkerkant van `ports:` in `docker-compose.yml` aan. |
| Witte pagina / 500 | `docker compose logs web` — daar staat de echte fout. |
| Database leeg | De volume bestond al. Doe `docker compose down -v` en opnieuw `up`. |
| Vreemde tekens (Öztürk) | Je hebt de SQL handmatig geladen zonder `SET NAMES utf8mb4`; die regel staat bovenaan beide bestanden. |

---

## 2. Mappenstructuur

```
voedselbank/
├─ docker-compose.yml      web (PHP+Apache), db (MySQL), phpmyadmin
├─ Dockerfile              PHP-image met de pdo_mysql-extensie
├─ db/
│  ├─ 01-schema.sql        alle tabellen, sleutels, indexen en views
│  └─ 02-seed.sql          testdata
├─ src/                    code buiten de webroot (niet opvraagbaar via de browser)
│  ├─ db.php               databaseverbinding, tijdzone + JSON-helpers
│  └─ auth.php             sessies, inloggen, rechtencontrole
├─ tests/
│  └─ api-test.js          regressietest op de API (node tests/api-test.js)
└─ public/                 dit is wat de webserver serveert
   ├─ login.html  index.html  klanten.html  producten.html
   ├─ leveranciers.html  pakketten.html  uitgifte.html
   ├─ rapportages.html  maandoverzicht.html  gebruikers.html
   ├─ account.html  pakbon.html
   ├─ assets/app.css      één stylesheet voor alle pagina's
   ├─ assets/app.js       gedeelde frontendcode (API, navigatie, meldingen)
   └─ api/                de backend-endpoints (JSON)
      auth.php  klanten.php  producten.php  leveranciers.php
      pakketten.php  uitgifte.php  rapportages.php  gebruikers.php  dashboard.php
```

`src/` staat bewust **buiten** `public/`. Zo kan niemand via de browser
`db.php` of `auth.php` opvragen.

---

## 3. Hoe de database in elkaar zit

18 tabellen en 2 views, allemaal InnoDB met echte foreign keys.

### Rollen en rechten

```
Rol ──< Rol_has_Permissie >── Permissie
 │
 └──< Gebruiker
```

Rechten hangen aan de **rol**, niet aan de persoon. Geef iemand een andere rol
en hij krijgt direct andere rechten. De tien permissies:

`pakket_beheren`, `pakket_uitgeven`, `klant_inzien`, `klant_beheren`,
`product_beheren`, `voorraad_corrigeren`, `leverancier_beheren`,
`levering_boeken`, `rapportage_export`, `gebruiker_beheren`.

### Klanten en dieetwensen

```
Klant ──< Gezinslid ──< Gezinslid_has_Wens >── Wens
```

Belangrijk: een dieetwens hangt aan het **gezinslid**, niet aan het gezin.
Anders kun je niet vastleggen dat alleen Bart glutenvrij moet eten.

`Gezinslid.Type` (baby/kind/volwassene) wordt **niet opgeslagen** maar berekend
in de view `vw_Gezinslid`, uit de geboortedatum. Een baby wordt vanzelf een kind.
`vw_Klant` telt de gezinsgrootte, de laatste uitgifte en het klantnummer (`K-001`).

`Klant.Opmerkingen` is een vrij tekstveld van de directie: voorkeuren en
afspraken die geen dieetwens zijn ("liever rijst dan pasta, geen koffie").
De vrijwilliger ziet die tekst bij het samenstellen en op de pakbon, maar kan
hem niet aanpassen — voorkeuren vastleggen hoort bij de klantadministratie.

### Hoe streng is een dieetwens?

`Wens.Streng` bepaalt wat er bij het samenstellen gebeurt:

| `Streng` | Wensen | Wat de applicatie doet |
|---|---|---|
| `1` | Notenallergie, Pinda-allergie, Schaaldierallergie | het product kan **niet** worden toegevoegd; ook de server weigert het, ook met `forceer` |
| `0` | Halal, Geen varkensvlees, Glutenvrij, Lactose-intolerant, Vegetarisch, Veganistisch | mag wel, maar alleen na een expliciete bevestiging |

De reden voor dat onderscheid: bij een ernstige allergie mag het product het
huis niet in, ook niet voor de andere gezinsleden. Bij de overige wensen kan
het gezin het onderling verdelen — als één van de vijf lactose-intolerant is,
kunnen de andere vier de melk prima drinken. Daarom staat er bij elke
waarschuwing om hoeveel personen het gaat, met hun namen.

**Uitzondering: het gezin wil het tóch.** Soms klopt de harde blokkade niet
voor dit gezin — de vader eet geen noten, de kinderen wel. De directie kan dat
per gezinslid en per wens vastleggen in `Gezinslid_has_Wens`:

| Kolom | Betekenis |
|---|---|
| `Toch_toestaan` | het gezin heeft laten weten dat het product welkom is |
| `Toelichting` | **verplicht**: waarom, in gewone taal |

Zonder toelichting telt de uitzondering niet — de backend zet `Toch_toestaan`
alleen op 1 als er ook een reden bij staat. Een vastgelegde uitzondering haalt
de harde blokkade weg voor dat gezin; de **waarschuwing blijft**, met de reden
erbij, zowel in het samenstelscherm als op de pakbon. Zo verdwijnt de
informatie nooit stilletjes: je ziet dat er bewust van is afgeweken, en waarom.

### Producten en voorraad

```
Categorie ──< Product ──< Levering_has_Product >── Levering >── Leverancier
                   │
                   ├──< Product_has_Pakket >── Pakket >── Klant
                   └──< Afvoer
```

`Product.Productnaam` en `Product.EAN` zijn `UNIQUE` (US-VRD-09 en US-VRD-10).
`Product.Houdbaar_tot` mag leeg zijn (luiers, shampoo). Er is **één** THT per
product, niet per partij — zie *Bekende beperkingen* onderaan.
`Product.Waarde` is de winkelwaarde per stuk; daarmee rekent het rapport de
gemiddelde pakketwaarde uit.

### Historie beschermen

Dit is de kern van "historische gegevens mogen niet verloren gaan":

| Relatie | Regel | Gevolg |
|---|---|---|
| `Product_has_Pakket → Product` | `ON DELETE RESTRICT` | een product dat ooit in een pakket zat kán de database niet verwijderen |
| `Levering_has_Product → Product` | `ON DELETE RESTRICT` | idem voor de leveringshistorie |
| `Afvoer → Product` | `ON DELETE RESTRICT` | idem voor afgevoerde producten |
| `Gezinslid → Klant` | `ON DELETE CASCADE` | gezinsleden horen bij het gezin en hebben los geen betekenis |
| `Pakket → Klant` | geen cascade | een klant met pakketten kan niet zomaar weg |
| `Pakket → Klant` | geen cascade | een klant met pakketten kan niet zomaar weg; de backend weigert `klanten.php?actie=verwijderen` met 409 en biedt "op non-actief" aan |
| `Gebruiker` | wordt nooit verwijderd, alleen `Actief = 0` | "samengesteld door Ank" blijft kloppen |

De backend vangt dit netjes af: je krijgt geen databasefout maar een
uitleg met een alternatief ("zet de voorraad op 0").

### Afwijkingen ten opzichte van de originele ERD

Alles hieronder is toegevoegd omdat een user story anders niet te bouwen was:

1. `Permissie` + `Rol_has_Permissie` — nodig voor US-GBR-05 t/m US-GBR-09.
2. `Gezinslid_has_Wens` — wensen per persoon in plaats van per gezin (US-KLT-06/07).
3. `Gezinslid.Relatie` los van het berekende `Type`.
4. `Afvoer` — zonder deze tabel is het verspillingspercentage (US-RAP-04) niet te berekenen.
5. `Product.Waarde` — nodig voor de gemiddelde pakketwaarde (US-RAP-02).
6. `Categorie.Kort` — korte naam voor de filterknoppen.
7. Datatypes rechtgezet: datums zijn `DATE`, aantallen `INT`, ja/nee `BOOLEAN`.
8. `E-mail` hernoemd naar `Email` (een streepje mag niet in een MySQL-kolomnaam).
9. `Wens.Streng` en `Wens.Conflict_tag` — zonder die twee kan de applicatie een
   ernstige allergie niet onderscheiden van een voorkeur (US-KLT-06/07, US-PAK-09).
10. `Klant.Opmerkingen` — voorkeuren die geen dieetwens zijn, zodat de
    vrijwilliger weet wat dit gezin nodig heeft (US-PAK-03).
11. `Gezinslid_has_Wens.Toch_toestaan` + `.Toelichting` — een vastgelegde
    uitzondering met reden, zie *Hoe streng is een dieetwens?*.

---

## 4. Hoe de backend werkt

Er is geen framework. Elke pagina in `public/` haalt zijn gegevens op bij een
bestand in `public/api/` dat JSON teruggeeft.

```
browser  ──fetch('api/klanten.php?actie=lijst')──>  api/klanten.php
                                                     │
                                                     ├─ src/auth.php  → mag deze gebruiker dit?
                                                     ├─ src/db.php    → PDO met prepared statements
                                                     └─ JSON terug
```

Elk endpoint begint hetzelfde:

```php
require __DIR__ . '/../../src/auth.php';
api_boot();                        // foutafhandeling: nooit een stacktrace naar de browser
$actie = $_GET['actie'] ?? 'lijst';

if ($actie === 'opslaan') {
    alleen_post();                 // 405 bij GET
    vereis_permissie('klant_beheren');   // 401 of 403
    ...
}
```

Endpoints per bestand (de actie staat in `?actie=`):

| Bestand | Acties |
|---|---|
| `auth.php` | `ik`, `login`, `logout`, `rechten`, `wachtwoord` |
| `klanten.php` | `lijst`, `wensen`, `wens`, `pakketten`, `opslaan`, `status`, `verwijderen` |
| `producten.php` | `lijst`, `categorieen`, `categorie`, `opslaan`, `voorraad`, `afvoeren`, `verwijderen` |
| `leveranciers.php` | `lijst`, `opslaan`, `actief`, `verwijderen`, `levering` |
| `pakketten.php` | `start`, `klant`, `lijst`, `pakket`, `pakbon`, `opslaan`, `verwijderen` |
| `uitgifte.php` | `wachtrij`, `zoek`, `kaart`, `identiteit`, `uitgeven`, `nietopgehaald` |
| `rapportages.php` | `overzicht`, `maand`, `export` |
| `gebruikers.php` | `lijst`, `opslaan`, `blokkeren`, `reset` |
| `dashboard.php` | geen actie, geeft het hele dashboard terug |

`klanten.php?actie=verwijderen` verwijdert een klant alleen als er geen pakketten
in de historie staan. Staan die er wel, dan komt er een `409` terug met
`reden: 'heeft_historie'` en het advies om de klant op non-actief te zetten —
hetzelfde patroon als bij producten en leveranciers.

Afspraken:

* **Alle** queries gaan via `prepare()`/`execute()` met `ATTR_EMULATE_PREPARES => false`.
  Daarmee is SQL-injectie uitgesloten (US-SEC-05).
* Meerdere samenhangende schrijfacties staan in een **transactie**
  (pakket opslaan, levering boeken, klant opslaan, afvoeren).
* Statuscodes: `200` gelukt, `401` niet ingelogd, `403` geen rechten,
  `404` niet gevonden, `405` verkeerde methode, `409` conflict
  (magazijn vol, product zit in een pakket, dubbel pakket),
  `422` validatiefout met een `fouten`-object per veld.
* De frontend zet die `fouten` automatisch onder het juiste invoerveld
  (`toonVeldfouten` in `app.js`).

---

## 5. Inloggen, sessies en rechten

### Wachtwoorden

Wachtwoorden staan **nooit** leesbaar in de database. Ze worden gehasht met
`password_hash($pw, PASSWORD_BCRYPT, ['cost' => 12])` en gecontroleerd met
`password_verify()`. Bij het inloggen wordt met `password_needs_rehash()`
gekeken of de hash nog sterk genoeg is en zo nodig vernieuwd.

Eisen aan een nieuw wachtwoord: minimaal 8 tekens, met letters én cijfers,
en anders dan het huidige.

### Inloggen

1. Gebruikersnaam **of** e-mailadres + wachtwoord.
2. Bestaat de gebruiker niet, of klopt het wachtwoord niet? Dan krijg je
   exact dezelfde melding. Zo kun je niet raden welke accounts bestaan.
3. Bij een fout wachtwoord wacht de server 0,3 seconde en telt hij
   `Mislukte_pogingen` op. Na 10 pogingen gaat het account op slot.
4. Bij een geslaagde login wordt `session_regenerate_id(true)` aangeroepen
   (tegen session fixation) en `Laatste_login` bijgewerkt.

### De sessie

In de sessie zit **alleen** het gebruikers-id. Rol en rechten worden bij elk
verzoek opnieuw uit de database gehaald. Word je geblokkeerd of krijg je een
andere rol, dan merk je dat meteen — ook met een open tabblad.

De cookie is `HttpOnly` (niet leesbaar vanuit JavaScript) en `SameSite=Strict`
(beschermt tegen CSRF). Na een uur zonder activiteit word je uitgelogd.

### Inloggen en uitloggen in beeld

Op het inlogscherm staat onder het formulier één regel: *"Nog geen account?
Vraag de directie om er een voor je aan te maken."* Er is bewust **geen**
registratiepagina. Een back-office met privacygevoelige klantgegevens mag geen
zelfregistratie hebben — dat zou Broken Access Control uit de OWASP Top 10 zijn.
Accounts worden alleen door de directie aangemaakt (US-GBR-06).

Uitloggen kan vanuit de zijbalk (knop met het woord "Uitloggen" onder je naam)
en vanaf Mijn account. Beide vragen eerst om bevestiging. In de eerste versie
was het alleen een pijltje-icoontje; tijdens het testen bleek dat niemand het
vond, dus is het een knop met tekst geworden.

### Rechten — drie lagen

| Laag | Wat het doet | Waar |
|---|---|---|
| Navigatie | pagina's waar je geen recht op hebt staan niet in het menu | `bouwZijbalk()` in `app.js` |
| Pagina | open je zo'n pagina toch via de URL, dan krijg je "geen toegang" | `start()` in `app.js` |
| **Server** | elk endpoint controleert zelf `vereis_permissie(...)` | `src/auth.php` |

De eerste twee zijn gemak. De derde is de echte beveiliging: knoppen verbergen
in de frontend is geen beveiliging, want de API is ook met `curl` te benaderen.

### Privacygevoelige klantgegevens

Adres, postcode, telefoonnummer en e-mailadres van klanten worden **door de
server weggelaten** uit het antwoord als je het recht `klant_beheren` niet hebt.
Een vrijwilliger ziet dus wél de gezinssamenstelling en de dieetwensen (die
heeft hij nodig om een pakket samen te stellen), maar niet de contactgegevens.
Het staat ook niet verstopt in de HTML: het is er gewoon niet.

### Een dashboard per rol

Iedereen komt na het inloggen op `index.html`, maar niemand ziet hetzelfde.
`api/dashboard.php` bouwt het dashboard op uit **blokken die per permissie
worden toegevoegd** — dezelfde `mag(...)`-controle als elk ander endpoint. Wat
je niet mag inzien zit niet in het antwoord, dus ook niet in de pagina.

| Rol | Cijfers | Lijsten | Takenlijst bovenaan |
|---|---|---|---|
| Directie | alles | alles | alles wat openstaat |
| Magazijnmedewerker | voorraad, onder minimum, THT, eerstvolgende levering | bij te bestellen producten, houdbaarheid, verwachte en recente leveringen | afvoeren en bijbestellen |
| Vrijwilliger | THT, pakketten deze week, nog samen te stellen, klaar voor uitgifte, klanten | houdbaarheid, gezinnen zonder pakket, klaar voor uitgifte, eigen concepten | gezinnen die nog wachten, pakketten om uit te geven |
| Administratie | klanten, medewerkers | wachtende aanvragen, weekgrafiek | aanvragen beoordelen |

De vrijwilliger ziet wel de houdbaarheid (dat bepaalt wat hij in een pakket mag
doen) maar niet de magazijncijfers: hij mag de voorraad corrigeren tijdens het
samenstellen, maar het magazijn beheren is niet zijn werk.

De takenlijst bovenaan is geen decoratie — het is letterlijk "wat moet ik nu
doen", met een link naar de pagina waar het kan.

---

## 6. De weekcyclus

```
maandag ──────────────────────────────> vrijdag
 leveringen inboeken (Leveranciers)      uitgifte (Uitgiftepunt)
 voorraad bijwerken (Producten)          legitimatie controleren
 pakketten samenstellen (Pakketten)      pakket uitgeven
```

* "Deze week" = vanaf maandag van de huidige week.
* Eén pakket per gezin per week (US-PAK-06); de server weigert een tweede.
* Een pakket doorloopt `Concept → Klaar → Uitgegeven`.
* Zodra een product in een pakket gaat, gaat het van de voorraad af.
  Haal je het er weer af, dan komt het terug.
* Een product dat over de THT is, verdwijnt uit de keuzelijst bij het samenstellen
  en kan ook via de API niet in een pakket worden gezet.
* Een product dat binnen drie dagen verloopt krijgt een label, zodat het juist
  als eerste wordt weggegeven.
* Een uitgegeven pakket is historie: niet meer te wijzigen en niet te verwijderen.
* Niet opgehaald? Dan boek je het pakket terug en staan de producten weer op voorraad.

---

## 7. Testen

### De testscript meedraaien

In `tests/api-test.js` staat een regressietest die de applicatie als vier
verschillende rollen benadert en 26 controles doet: rechten per endpoint,
afgeschermde contactgegevens, beschermde historie, de allergieblokkade en het
dashboard per rol. Je hebt Node 18 of nieuwer nodig (geen npm-pakketten):

```bash
# de applicatie moet draaien (docker compose up -d)
node tests/api-test.js
```

Alles goed, dan eindigt hij met `26 geslaagd, 0 mislukt` en afsluitcode 0.

De interessantste controles, omdat ze niet in de browser te zien zijn:

| Controle | Waarom het belangrijk is |
|---|---|
| vrijwilliger krijgt 403 op `klanten.php?actie=verwijderen` | de knop is verborgen, maar dat is geen beveiliging |
| vrijwilliger krijgt geen `adres` in het antwoord | privacygevoelige gegevens zitten niet in de JSON |
| klant met pakketten geeft 409 | historische gegevens gaan niet verloren |
| categorie met producten geeft 409 | idem, en met een voorstel om de producten te verhuizen |
| een notenproduct bij een notenallergie geeft 409, **ook met `forceer: true`** | een harde blokkade is niet te omzeilen via de API |
| een product over de THT geeft 409, ook met `forceer: true` | idem |

### Zelf met curl kijken

Snel controleren of de rechten kloppen, zonder de browser:

```bash
# inloggen als vrijwilliger, cookie bewaren
curl -s -c v.txt -X POST -H 'Content-Type: application/json' \
  -d '{"gebruikersnaam":"a.degroot","wachtwoord":"voedselbank"}' \
  http://localhost:8080/api/auth.php?actie=login

# gebruikersbeheer opvragen -> moet 403 geven
curl -s -o /dev/null -w '%{http_code}\n' -b v.txt \
  http://localhost:8080/api/gebruikers.php?actie=lijst

# klantgegevens opvragen -> 200, maar zonder adres/telefoon/e-mail
curl -s -b v.txt http://localhost:8080/api/klanten.php?actie=lijst
```

---

## 8. Bekende beperkingen

Dingen die we bewust niet hebben gebouwd, met de reden erbij.

**Eén THT-datum per product, niet per partij.** In het echt komt hetzelfde
product in meerdere leveringen binnen, elk met een eigen houdbaarheidsdatum.
Ons model heeft één `Houdbaar_tot` per product. Dat is genoeg om te waarschuwen
en om verlopen producten te blokkeren, maar niet om partijen uit elkaar te
houden. Een volgende versie zou een tabel `Partij` krijgen tussen `Levering` en
`Product`, met de voorraad per partij. Dat raakt de voorraadadministratie overal,
dus daar is dit project te kort voor.

**Geen magazijncapaciteit.** De casus stelt geen maximum aan de voorraad, dus
er is geen capaciteitsgrens meer. Het productenscherm toont alleen hoeveel er
ligt, over hoeveel producten dat verdeeld is, en wat er onder de minimumvoorraad
zit of over de datum is.

**Geen zelfregistratie.** Accounts worden alleen door de directie aangemaakt
(US-GBR-06). Een open registratiepagina zou Broken Access Control zijn: iedereen
met de URL kon dan bij privacygevoelige klantgegevens.

**Niet-opgehaalde pakketten worden verwijderd.** De producten gaan terug naar de
voorraad, maar er blijft niet staan dát een gezin niet is komen opdagen. Voor een
volgende versie zou een status `Niet opgehaald` beter zijn dan verwijderen.

**Een gezin opslaan vervangt alle gezinsleden.** `klanten.php?actie=opslaan`
gooit de gezinsleden weg en zet ze opnieuw neer, inclusief hun wensen en
uitzonderingen. Het eindresultaat klopt — wat op het scherm staat, staat daarna
in de database — maar de gezinsleden krijgen wel nieuwe id's. Omdat alleen
`Gezinslid_has_Wens` naar `Gezinslid` verwijst (en die rijen worden in dezelfde
transactie opnieuw geschreven) gaat er niets verloren. Netter zou zijn: per lid
kijken of het nieuw, gewijzigd of verwijderd is. Dat is een goed verbetervoorstel.
