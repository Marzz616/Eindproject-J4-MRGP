/**
 * Regressietest op de API van de voedselbank-applicatie.
 *
 * Test de dingen die je niet in de browser kunt zien: of de server zelf de
 * rechten bewaakt (US-SEC-01/02), of historische gegevens echt beschermd zijn
 * en of een harde allergieblokkade ook met een omweg niet te passeren is.
 *
 * Draaien (de applicatie moet aanstaan, Node 18 of nieuwer):
 *     node tests/api-test.js
 *
 * Draait de applicatie op een andere poort?
 *     VB_URL=http://localhost:9000 node tests/api-test.js
 *
 * De test maakt zelf een categorie aan en verwijdert die weer; verder laat
 * hij de data met rust. Afsluitcode 0 = alles goed, 1 = er is iets mis.
 */
const B = (process.env.VB_URL || 'http://localhost:8080') + '/api/';
let ok = 0, fout = 0;

function check(naam, voorwaarde, extra = '') {
  if (voorwaarde) { ok++; console.log('  OK   ' + naam); }
  else { fout++; console.log('  FOUT ' + naam + (extra ? '  -> ' + extra : '')); }
}

async function login(gnaam) {
  const r = await fetch(B + 'auth.php?actie=login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ gebruikersnaam: gnaam, wachtwoord: 'voedselbank' }),
  });
  if (!r.ok) { throw new Error('login mislukt voor ' + gnaam); }
  return r.headers.getSetCookie().map(c => c.split(';')[0]).join('; ');
}

async function api(cookie, pad, body) {
  const r = await fetch(B + pad, {
    method: body ? 'POST' : 'GET',
    headers: { 'Content-Type': 'application/json', Cookie: cookie },
    body: body ? JSON.stringify(body) : undefined,
  });
  let d = null;
  try { d = await r.json(); } catch (e) { /* geen json */ }
  return { status: r.status, d };
}

(async () => {
  const D = await login('p.abraham');     // Directie
  const M = await login('r.veenstra');    // Magazijnmedewerker
  const V = await login('a.degroot');     // Vrijwilliger
  const A = await login('m.snel');        // Administratie

  console.log('\n== rechten (US-SEC-01/02) ==');
  check('vrijwilliger mag geen klant verwijderen',
    (await api(V, 'klanten.php?actie=verwijderen', { id: 999 })).status === 403);
  check('vrijwilliger mag geen categorie verwijderen',
    (await api(V, 'producten.php?actie=categorie_verwijderen', { id: 1 })).status === 403);
  check('magazijn mag geen klanten inzien',
    (await api(M, 'klanten.php?actie=lijst')).status === 403);
  check('administratie mag geen producten beheren',
    (await api(A, 'producten.php?actie=categorie', { naam: 'Stiekem' })).status === 403);
  check('magazijn mag wel categorieen beheren',
    (await api(M, 'producten.php?actie=categorieen')).status === 200);

  console.log('\n== privacy: contactgegevens (US-SEC-02) ==');
  const vl = await api(V, 'klanten.php?actie=lijst');
  check('vrijwilliger ziet geen adres', vl.d.klanten[0].adres === undefined);
  check('vrijwilliger ziet wel de voorkeuren', 'opmerkingen' in vl.d.klanten[0]);
  const dl = await api(D, 'klanten.php?actie=lijst');
  check('directie ziet wel adres', typeof dl.d.klanten[0].adres === 'string');

  console.log('\n== historie beschermen ==');
  const metHist = dl.d.klanten.find(k => k.laatste);
  const vw = await api(D, 'klanten.php?actie=verwijderen', { id: metHist.id });
  check('klant met pakketten kan niet weg', vw.status === 409 && vw.d.reden === 'heeft_historie',
    JSON.stringify(vw.d));
  const cats = await api(D, 'producten.php?actie=categorieen');
  const volle = cats.d.find(c => c.aantal > 0);
  const cv = await api(D, 'producten.php?actie=categorie_verwijderen', { id: volle.id });
  check('categorie met producten kan niet weg', cv.status === 409 && cv.d.reden === 'heeft_producten',
    JSON.stringify(cv.d));

  console.log('\n== categorie toevoegen / verplaatsen / verwijderen ==');
  const nieuw = await api(D, 'producten.php?actie=categorie', { naam: 'Testcat ' + Date.now(), kort: 'Test' });
  check('nieuwe categorie aangemaakt', nieuw.status === 200 && nieuw.d.id > 0);
  const weg = await api(D, 'producten.php?actie=categorie_verwijderen', { id: nieuw.d.id });
  check('lege categorie mag weg', weg.status === 200, JSON.stringify(weg.d));

  console.log('\n== allergie, uitzondering en THT (US-PAK) ==');
  const start = await api(V, 'pakketten.php?actie=start');
  const bakker = start.d.klanten.find(k => k.naam.includes('Bakker'));
  const jafari = start.d.klanten.find(k => k.naam.includes('Jafari'));

  const kb = await api(V, 'pakketten.php?actie=klant&id=' + bakker.id);
  const noten = Object.values(kb.d.wensen).find(w => w.tag === 'noten');
  check('Bakker heeft een vastgelegde uitzondering', noten && noten.uitzondering === true);
  check('uitzondering heft de harde blokkade op', noten && noten.streng === false);
  check('de reden komt mee', noten && (noten.toelichting || '').includes('Bart'));

  const kj = await api(V, 'pakketten.php?actie=klant&id=' + jafari.id);
  const notenJ = Object.values(kj.d.wensen).find(w => w.tag === 'noten');
  check('El Jafari heeft wel een harde notenblokkade', notenJ && notenJ.streng === true);

  const prod = start.d.producten || [];
  const pindakaas = prod.find(p => (p.allergenen || '').includes('noten') || /pinda/i.test(p.naam));
  const verlopenP = prod.find(p => p.verlopen);
  if (pindakaas) {
    const poging = await api(V, 'pakketten.php?actie=opslaan', {
      id: 0, klant: jafari.id, status: 'Concept', forceer: true,
      regels: [{ product: pindakaas.id, aantal: 1 }],
    });
    check('geblokkeerd product kan ook met forceer niet mee',
      poging.status === 409 && poging.d.reden === 'geblokkeerd', JSON.stringify(poging.d));
  } else {
    console.log('  (overgeslagen: geen notenproduct in de voorraad)');
  }

  if (verlopenP) {
    const poging = await api(V, 'pakketten.php?actie=opslaan', {
      id: 0, klant: bakker.id, status: 'Concept', forceer: true,
      regels: [{ product: verlopenP.id, aantal: 1 }],
    });
    check('product over de THT kan ook met forceer niet mee',
      poging.status === 409 && poging.d.reden === 'geblokkeerd', JSON.stringify(poging.d));
  } else {
    console.log('  (overgeslagen: geen verlopen product in de voorraad)');
  }

  console.log('\n== dashboard per rol ==');
  for (const [naam, c, verwacht, nietVerwacht] of [
    ['directie', D, 'Medewerkers', null],
    ['magazijn', M, 'Voorraad totaal', 'Klanten actief'],
    ['vrijwilliger', V, 'Pakketten deze week', 'Voorraad totaal'],
    ['administratie', A, 'Klanten actief', 'Voorraad totaal'],
  ]) {
    const r = await api(c, 'dashboard.php');
    const labels = r.d.kaarten.map(k => k.label);
    check(naam + ': ziet "' + verwacht + '"', labels.includes(verwacht), labels.join(', '));
    if (nietVerwacht) {
      check(naam + ': ziet geen "' + nietVerwacht + '"', !labels.includes(nietVerwacht), labels.join(', '));
    }
  }

  console.log('\n== tijdzone ==');
  const d = await api(D, 'dashboard.php');
  check('dashboard laadt zonder fout', d.status === 200);

  console.log('\n' + ok + ' geslaagd, ' + fout + ' mislukt');
  process.exit(fout ? 1 : 0);
})();
