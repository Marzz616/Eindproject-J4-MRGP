import { fileURLToPath, URL } from 'node:url';
import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import vue from '@vitejs/plugin-vue';

/**
 * Vite bouwt de Vue-app. De laravel-plugin zorgt ervoor dat Laravel weet
 * welke bestanden hij in de pagina moet zetten (de @vite-regel in
 * resources/views/app.blade.php).
 *
 *   npm run dev     bouwt live mee tijdens het ontwikkelen
 *   npm run build   maakt de bestanden in public/build voor de oplevering
 *
 * Een proxy voor /api is niet meer nodig: Laravel levert de pagina én de API,
 * dus staan ze voor de browser op hetzelfde adres en werkt de sessiecookie.
 */
export default defineConfig({
  plugins: [
    laravel({
      input: ['resources/js/app.js'],
      refresh: true,
    }),
    vue(),
  ],
  resolve: {
    alias: { '@': fileURLToPath(new URL('./resources/js', import.meta.url)) },
  },
});
